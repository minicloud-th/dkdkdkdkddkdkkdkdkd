# KODDYKUB Hero asset sources

Hero uses 15 new still images. They are generic landscape/fantasy imagery, not official artwork, screenshots, fan art, or endorsement from any named game publisher. The source pages and license summaries are kept here; the public-facing list is also in `public/hero-video-credits.html`.

1. **Surreal abstract landscape with vivid colors** — Eugene Golovesov; Pexels License; [source page](https://www.pexels.com/photo/surreal-abstract-landscape-with-vibrant-colors-39033732/), [license](https://www.pexels.com/license/).
2. **Rocky mountain landscape with stream** — Jozsef Mihalyi; Pexels License; [source page](https://www.pexels.com/photo/rocky-landscape-with-a-mountain-stream-and-clouds-15575235/), [license](https://www.pexels.com/license/).
3. **A Dark Landscape** — Herbert E. Crowley, The Metropolitan Museum of Art; Open Access public-domain image; [collection page](https://www.metmuseum.org/art/collection/search/700286), [Open Access terms](https://www.metmuseum.org/about-the-met/policies-and-documents/open-access).
4. **Surreal mountains and sea** — Steve A. Johnson; Pexels License; [source page](https://www.pexels.com/photo/mountain-on-sea-rendered-in-3d-10109585/), [license](https://www.pexels.com/license/).
5. **Misty forest and river** — Johannes Plenio; Pexels License; [source page](https://www.pexels.com/photo/fantasy-forest-in-fog-14332265/), [license](https://www.pexels.com/license/).
6. **Nature World Fantasy landscape** — Pradeep Sachintha; Pexels License; [source page](https://www.pexels.com/photo/nature-world-fantasy-18907088/), [license](https://www.pexels.com/license/).
7. **Hills and forest at sunset** — Mo Eid; Pexels License; [source page](https://www.pexels.com/photo/landscape-of-hills-and-forest-at-sunset-11592804/), [license](https://www.pexels.com/license/).
8. **Marrakesh dunes** — Manon; Pexels License; [source page](https://www.pexels.com/photo/aerial-shot-of-a-landscape-6376610/), [license](https://www.pexels.com/license/).
9. **Warrior statue silhouette** — Patty Fernandini León (Bepafel); Pexels License; [source page](https://www.pexels.com/photo/silhouette-of-man-holing-sword-5833434/), [license](https://www.pexels.com/license/).
10. **Warrior Figure** — David Stanley; CC BY 4.0, attribution required; [source page](https://commons.wikimedia.org/wiki/File:Warrior_Figure_%2855222962325%29.jpg), [license](https://creativecommons.org/licenses/by/4.0/deed.en).
11. **Mountains full of green trees** — Zane; Pexels License; [source page](https://www.pexels.com/photo/mountains-full-of-green-trees-6092445/), [license](https://www.pexels.com/license/).
12. **Desert dune landscape** — pxhere / Wikimedia Commons; CC0 1.0; [source page](https://commons.wikimedia.org/wiki/File:Landscape,_sand,_desert,_dune,_adventure,_africa,.jpg), [license](https://creativecommons.org/publicdomain/zero/1.0/).
13. **Deep forest behind rocks** — Annaëlle Quionquion; Pexels License; [source page](https://www.pexels.com/photo/deep-forest-behind-rocks-17703497/), [license](https://www.pexels.com/license/).
14. **Moonlit mountain landscape** — Pixabay contributor via Pexels; Pexels License; [source page](https://www.pexels.com/photo/aerial-photography-of-glacier-hills-at-winter-207130/), [license](https://www.pexels.com/license/).
15. **Autumn forest at golden hour** — Khoa Vo; Pexels License; [source page](https://www.pexels.com/photo/enchanting-autumn-forest-at-golden-hour-29054973/), [license](https://www.pexels.com/license/).

Pexels says its photos may be used on commercial websites/e-commerce shops, attribution is optional, modification is allowed, and images may not be redistributed as a stock-photo service or used to imply brand/person endorsement. The Wikimedia CC BY 4.0 statue image is credited on the public credit page. No YouTube footage is used in this all-image Hero set.
