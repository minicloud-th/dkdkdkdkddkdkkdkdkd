# บันทึกแหล่งข้อมูลภายนอก

ใช้ประกอบการตัดสินใจในงาน Hero media เท่านั้น (2026-10-16)

- YouTube Terms of Service: https://www.youtube.com/static?template=terms
  - ข้อสรุปที่ใช้: ไม่ควรดาวน์โหลด/สำเนาเนื้อหาจาก YouTube เว้นแต่มีช่องทางดาวน์โหลดที่บริการอนุญาตหรือได้รับอนุญาตจากเจ้าของสิทธิ์
- YouTube API Services Developer Policies: https://developers.google.com/youtube/terms/developer-policies
  - ข้อสรุปที่ใช้: ห้ามดาวน์โหลด นำเข้า สำรอง แคช หรือเก็บสำเนา audiovisual content โดยไม่มีการอนุมัติที่เกี่ยวข้อง และต้องปฏิบัติตามข้อกำหนดของ embedded player

แนวทางที่เลือก: ไม่ดาวน์โหลดคลิปจาก YouTube; ใช้เฉพาะ MP4 ที่ผู้ใช้จัดหาและระบุว่ามีสิทธิ์ใช้งาน โดยเก็บเป็นไฟล์ local ในโปรเจกต์

## Pixabay hero clips (2026-10-16)

- Pixabay Content License summary: https://pixabay.com/service/license-summary/
  - Allows free use and adaptation without required attribution; prohibits standalone redistribution and restricts commercial use of assets containing recognizable trademarks/brands. Third-party rights still need checking.
- Pixabay search set used for licensed fantasy/game-style stock clips: https://pixabay.com/videos/search/fantasy%20game/
- Representative item pages verified to show “Free for use under the Pixabay Content License” and “Free download”:
  - https://pixabay.com/videos/light-waves-fantasy-game-sifi-116825/
  - https://pixabay.com/videos/ai-generated-illusion-game-role-224484/
  - https://pixabay.com/videos/ai-generated-guard-soldier-medieval-253170/
  - https://pixabay.com/videos/fantasy-dark-fantasy-epic-fight-304931/
- Commons fan-art guidance: https://commons.wikimedia.org/wiki/Commons:Fan_art — highlights that fan art must not copy protected creative elements and must be released under a commercial-use-capable free license to qualify there.
- Production choice: Hero now uses 15 generic fantasy/game-style stock MP4s from Pixabay, each trimmed to 4 seconds, locally hosted under `public/assets/game-videos/`. These are not presented as official or licensed fan art of named game franchises. Per-clip creator and source links are listed at `public/hero-video-credits.html`.
