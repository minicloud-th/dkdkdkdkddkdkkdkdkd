# YouTube gameplay check — KODDYKUB

The user selected a 15-image Hero set, so no YouTube video is included in the current Hero. The images are new licensed generic landscapes/fantasy artwork, not official game art; see [HERO_ASSET_SOURCES.md](HERO_ASSET_SOURCES.md) and the public [media credits page](public/hero-video-credits.html).

No new Wuthering Waves YouTube gameplay video passed both requirements previously specified: an explicit video-level Creative Commons Attribution license and an embed that plays. For example, `QC4YogoIksM` played in the embed test, but the CC BY-SA notice applied only to music; `WTyUzsVAyro` and `JbTct7wSHXU` did not verify both license and playback. They are not used.

YouTube distinguishes its default Standard license from Creative Commons Attribution, and CC BY reuse requires attribution: [YouTube Help — License types](https://support.google.com/youtube/answer/2797468?hl=en). No YouTube video was downloaded or embedded in the new all-image set.
