/**
 * KODDYKUB navbar and member dialog for the landing page.
 * The only data source is the localStorage entry written by the sign-in page.
 * Every value taken from storage is escaped before it is placed into HTML.
 */
const STORAGE_KEY = 'koddykub_user';

const esc = (value) =>
  String(value ?? '').replace(/[&<>"']/g, (c) => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' })[c]);

const initials = (user) => esc(user.avatarText || String(user.name || '?').slice(0, 2).toUpperCase());

export function getCurrentUser() {
  try {
    const raw = localStorage.getItem(STORAGE_KEY);
    return raw ? JSON.parse(raw) : null;
  } catch {
    return null;
  }
}

export function setCurrentUser(user) {
  try {
    if (user) localStorage.setItem(STORAGE_KEY, JSON.stringify(user));
    else localStorage.removeItem(STORAGE_KEY);
  } catch {
    /* storage unavailable: nothing to persist */
  }
  renderAuthNavbar();
}

export function renderAuthNavbar() {
  const user = getCurrentUser();
  const slot = document.getElementById('auth-nav-slot');

  if (slot) {
    slot.innerHTML = user
      ? `<button type="button" id="btn-user-profile" class="user-chip" aria-haspopup="dialog" title="ดูข้อมูลบัญชี">
           <span class="user-chip__avatar" aria-hidden="true">${initials(user)}</span>
           <span class="user-chip__name">${esc(user.name)}</span>
         </button>`
      : `<a class="nav-signin" href="/auth.html">เข้าสู่ระบบ</a>`;
    document.getElementById('btn-user-profile')?.addEventListener('click', openMemberDialog);
  }

  updateMobileAuth(user);
}

function updateMobileAuth(user) {
  const nav = document.getElementById('mobile-nav');
  if (!nav) return;
  nav.querySelector('.mobile-auth')?.remove();

  const block = document.createElement('div');
  block.className = 'mobile-auth';
  if (user) {
    block.innerHTML = `
      <div class="mobile-auth__who">
        <span class="user-chip__avatar" aria-hidden="true">${initials(user)}</span>
        <span class="mobile-auth__name">${esc(user.name)}</span>
      </div>
      <button type="button" class="mobile-auth__out">ออกจากระบบ</button>`;
    block.querySelector('.mobile-auth__out')?.addEventListener('click', () => setCurrentUser(null));
  } else {
    block.innerHTML = `<a href="/auth.html" class="mobile-auth__cta">เข้าสู่ระบบ</a>`;
  }
  nav.appendChild(block);
}

export function openMemberDialog() {
  const user = getCurrentUser();
  if (!user || document.querySelector('.member-dialog')) return;

  const orders = Array.isArray(user.orders) ? user.orders : [];
  const list = orders.length
    ? orders
        .map(
          (o) => `<li class="order">
            <div>
              <p class="order__title">${esc(o.title)}</p>
              <p class="order__meta"><span>รหัส ${esc(o.id)}</span><span>${esc(o.date)}</span></p>
            </div>
            <div class="order__side"><span class="order__status">${esc(o.status)}</span><span>${esc(o.price)}</span></div>
          </li>`
        )
        .join('')
    : `<li class="order order--empty">ยังไม่มีประวัติคำสั่งซื้อ</li>`;

  const dialog = document.createElement('dialog');
  dialog.className = 'member-dialog';
  dialog.setAttribute('aria-labelledby', 'member-title');
  dialog.innerHTML = `
    <button type="button" class="dialog-close" aria-label="ปิด">×</button>
    <div class="dialog-inner">
      <div class="member__head">
        <span class="user-chip__avatar user-chip__avatar--lg" aria-hidden="true">${initials(user)}</span>
        <div class="member__id">
          <h2 id="member-title">${esc(user.name)}</h2>
          <p class="member__email">${esc(user.email)}</p>
        </div>
      </div>
      <h3 class="member__h3">ประวัติคำสั่งซื้อ <span>${orders.length} รายการ</span></h3>
      <ul class="orders">${list}</ul>
      <div class="member__actions">
        <a href="/#features" class="member__shop">ดูสินค้าในร้าน</a>
        <button type="button" class="member__out">ออกจากระบบ</button>
      </div>
    </div>`;
  document.body.appendChild(dialog);

  dialog.querySelector('.dialog-close')?.addEventListener('click', () => dialog.close());
  dialog.querySelector('.member__shop')?.addEventListener('click', () => dialog.close());
  dialog.querySelector('.member__out')?.addEventListener('click', () => {
    setCurrentUser(null);
    dialog.close();
    showToast('ออกจากระบบแล้ว');
  });
  dialog.addEventListener('click', (event) => {
    if (event.target === dialog) dialog.close();
  });
  dialog.addEventListener('close', () => dialog.remove());
  dialog.showModal();
}

export function showToast(message) {
  document.getElementById('koddy-toast')?.remove();
  const toast = document.createElement('div');
  toast.id = 'koddy-toast';
  toast.className = 'koddy-toast';
  toast.setAttribute('role', 'status');
  toast.textContent = message;
  document.body.appendChild(toast);
  setTimeout(() => {
    toast.classList.add('is-leaving');
    setTimeout(() => toast.remove(), 300);
  }, 3500);
}

if (document.readyState === 'loading') document.addEventListener('DOMContentLoaded', renderAuthNavbar);
else renderAuthNavbar();