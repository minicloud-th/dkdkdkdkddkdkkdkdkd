/**
 * KODDYKUB landing chrome: theme toggle, mobile menu, section progress, page loader.
 * Loaded as a module at the end of <head>; every block is guarded so a missing element is harmless.
 */
const THEME_KEY = 'koddykub-theme';
const root = document.documentElement;

/* ---------- Theme ---------- */
const themeButtons = [...document.querySelectorAll('[data-theme-toggle]')];

function applyTheme(theme) {
  root.dataset.theme = theme;
  // The label names the action the button performs, so it changes with the current theme.
  const label = theme === 'dark' ? 'เปลี่ยนเป็นธีมสว่าง' : 'เปลี่ยนเป็นธีมมืด';
  themeButtons.forEach((btn) => btn.setAttribute('aria-label', label));
}

let savedTheme = 'dark';
try {
  savedTheme = localStorage.getItem(THEME_KEY) === 'light' ? 'light' : 'dark';
} catch {
  /* storage blocked: keep the default theme */
}
applyTheme(savedTheme);

themeButtons.forEach((btn) =>
  btn.addEventListener('click', () => {
    const next = root.dataset.theme === 'dark' ? 'light' : 'dark';
    applyTheme(next);
    try {
      localStorage.setItem(THEME_KEY, next);
    } catch {
      /* ignore: the choice still applies for this visit */
    }
  })
);

/* ---------- Mobile menu ---------- */
const burger = document.querySelector('.nav-burger');
const mobileNav = document.getElementById('mobile-nav');

if (burger && mobileNav) {
  const setOpen = (open) => {
    mobileNav.hidden = !open;
    burger.setAttribute('aria-expanded', String(open));
  };
  setOpen(false);

  burger.addEventListener('click', () => setOpen(mobileNav.hidden));
  mobileNav.addEventListener('click', (event) => {
    if (event.target instanceof Element && event.target.closest('a')) setOpen(false);
  });
  document.addEventListener('keydown', (event) => {
    if (event.key === 'Escape' && !mobileNav.hidden) {
      setOpen(false);
      burger.focus();
    }
  });
}

/* ---------- Section queue (desktop) ---------- */
const queueLinks = [...document.querySelectorAll('.section-queue a[data-section]')];
if (queueLinks.length && 'IntersectionObserver' in window) {
  const observer = new IntersectionObserver(
    (entries) => {
      entries.forEach((entry) => {
        if (!entry.isIntersecting) return;
        queueLinks.forEach((link) => link.classList.toggle('active', link.dataset.section === entry.target.id));
      });
    },
    { rootMargin: '-40% 0px -55% 0px' }
  );
  queueLinks.forEach((link) => {
    const target = document.getElementById(link.dataset.section);
    if (target) observer.observe(target);
  });
}

/* ---------- Reading progress ---------- */
const progressFill = document.querySelector('.scroll-progress__fill');
if (progressFill) {
  const updateProgress = () => {
    const max = document.documentElement.scrollHeight - window.innerHeight;
    const ratio = max > 0 ? window.scrollY / max : 0;
    progressFill.style.transform = `scaleY(${Math.min(1, Math.max(0, ratio))})`;
  };
  window.addEventListener('scroll', updateProgress, { passive: true });
  updateProgress();
}

/* ---------- Page loader ---------- */
const loader = document.getElementById('page-loader');
const hideLoader = () => loader?.classList.add('is-hidden');
if (document.readyState === 'complete') hideLoader();
else window.addEventListener('load', hideLoader, { once: true });

/* ---------- Optional hero enhancement (tilted grid) ----------
   Loaded only if its files exist, so a missing asset never breaks the page or the build. */
const HERO_CSS = '/tilted-grid-assets/tilted-grid-hero.css';
const HERO_JS = '/tilted-grid-assets/tilted-grid-hero.js';
if (document.getElementById('tilted-grid-hero-root')) {
  fetch(HERO_CSS, { method: 'HEAD' })
    .then((res) => {
      if (!res.ok) return;
      const link = document.createElement('link');
      link.rel = 'stylesheet';
      link.href = HERO_CSS;
      document.head.appendChild(link);
      return import(/* @vite-ignore */ HERO_JS);
    })
    .catch(() => {
      /* hero enhancement is optional */
    });
}
