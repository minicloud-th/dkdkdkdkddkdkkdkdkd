import { createServer } from 'node:http';
import { stat } from 'node:fs/promises';
import { createReadStream } from 'node:fs';
import { extname, resolve, sep } from 'node:path';

/**
 * Preview server for KODDYKUB.
 * - Pages (/, /auth.html) come from the project root, the same files Vite uses.
 * - Other static files come from public/.
 * - .ts/.tsx/.jsx modules under src/ are bundled with esbuild on request, because browsers cannot run TypeScript.
 */

const workspaceRoot = resolve('.');
const publicRoot = resolve('public');
const srcRoot = resolve('src');
const port = Number(process.env.PORT || 3000);

const TYPES = {
  '.html': 'text/html; charset=utf-8',
  '.css': 'text/css; charset=utf-8',
  '.js': 'text/javascript; charset=utf-8',
  '.mjs': 'text/javascript; charset=utf-8',
  '.json': 'application/json; charset=utf-8',
  '.svg': 'image/svg+xml',
  '.jpg': 'image/jpeg',
  '.jpeg': 'image/jpeg',
  '.gif': 'image/gif',
  '.png': 'image/png',
  '.webp': 'image/webp',
  '.webm': 'video/webm',
  '.mp4': 'video/mp4',
  '.woff2': 'font/woff2',
  '.woff': 'font/woff',
  '.ico': 'image/x-icon',
};

const PAGES = new Map([
  ['/', 'index.html'],
  ['/index.html', 'index.html'],
  ['/auth.html', 'auth.html'],
]);

const inside = (base, target) => target === base || target.startsWith(base + sep);

async function statOrNull(path) {
  try {
    return await stat(path);
  } catch {
    return null;
  }
}

const notFound = (res) => res.writeHead(404, { 'Content-Type': 'text/plain; charset=utf-8' }).end('Not found');

async function bundleModule(file) {
  const esbuild = await import('esbuild');
  const result = await esbuild.build({
    entryPoints: [file],
    bundle: true,
    write: false,
    format: 'esm',
    target: 'es2020',
    jsx: 'automatic',
    define: { 'process.env.NODE_ENV': '"development"' },
    logLevel: 'silent',
  });
  return result.outputFiles[0].text;
}

async function serveFile(req, res, file, size) {
  const type = TYPES[extname(file).toLowerCase()] || 'application/octet-stream';
  const cache = file.includes(`${sep}assets${sep}`) ? 'public, max-age=86400' : 'no-cache';
  res.setHeader('Content-Type', type);
  res.setHeader('Cache-Control', cache);
  res.setHeader('Accept-Ranges', 'bytes');

  if (req.method === 'HEAD') {
    res.writeHead(200, { 'Content-Length': size }).end();
    return;
  }

  const match = /^bytes=(\d+)-(\d*)$/.exec(req.headers.range ?? '');
  if (match) {
    const start = Number(match[1]);
    const end = Math.min(match[2] ? Number(match[2]) : size - 1, size - 1);
    if (start >= size || start > end) {
      res.writeHead(416, { 'Content-Range': `bytes */${size}` }).end();
      return;
    }
    res.writeHead(206, { 'Content-Range': `bytes ${start}-${end}/${size}`, 'Content-Length': end - start + 1 });
    createReadStream(file, { start, end }).pipe(res);
    return;
  }

  res.writeHead(200, { 'Content-Length': size });
  createReadStream(file).pipe(res);
}

const server = createServer(async (req, res) => {
  try {
    const path = decodeURIComponent(new URL(req.url ?? '/', 'http://localhost').pathname);

    if (PAGES.has(path)) {
      const file = resolve(workspaceRoot, PAGES.get(path));
      const info = await statOrNull(file);
      if (!info?.isFile()) return notFound(res);
      return serveFile(req, res, file, info.size);
    }

    if (/^\/src\/.+\.(tsx|ts|jsx)$/.test(path)) {
      const file = resolve(workspaceRoot, '.' + path);
      const info = await statOrNull(file);
      if (!inside(srcRoot, file) || !info?.isFile()) return notFound(res);
      try {
        const code = await bundleModule(file);
        res.writeHead(200, { 'Content-Type': TYPES['.js'], 'Cache-Control': 'no-cache' }).end(code);
      } catch (error) {
        console.error(`Failed to bundle ${path}:`, error.message);
        res.writeHead(500, { 'Content-Type': 'text/plain; charset=utf-8' }).end('Module build failed');
      }
      return;
    }

    let file = resolve(publicRoot, '.' + path);
    if (!inside(publicRoot, file)) return notFound(res);
    let info = await statOrNull(file);
    if (info?.isDirectory()) {
      file = resolve(file, 'index.html');
      info = await statOrNull(file);
    }
    if (!info?.isFile()) return notFound(res);
    return serveFile(req, res, file, info.size);
  } catch (error) {
    console.error(error);
    res.writeHead(500).end();
  }
});

server.listen(port, '0.0.0.0', () => console.log(`KODDYKUB preview listening on port ${port}`));
