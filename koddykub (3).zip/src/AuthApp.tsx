import React, { useEffect, useRef, useState } from 'react';
import { ArrowLeft, AlertCircle, CheckCircle2, Eye, EyeOff, Loader2, Moon, Sun, X } from 'lucide-react';

export interface User {
  id: string;
  name: string;
  email: string;
  role: string;
  points: number;
  provider: string;
  avatarText?: string;
  orders?: Array<{
    id: string;
    title: string;
    date: string;
    price: string;
    status: string;
  }>;
}

type Provider = 'Google' | 'Discord' | 'GitHub';
type FieldId = 'username' | 'email' | 'password' | 'confirmPassword';
type Notice = { message: string; type: 'error' | 'success' };

const ICONS: Record<Provider, React.ReactNode> = {
  Google: (
    <svg className="h-[18px] w-[18px] shrink-0" viewBox="0 0 24 24" aria-hidden="true">
      <path fill="#4285F4" d="M22.56 12.25c0-.78-.07-1.53-.2-2.25H12v4.26h5.92c-.26 1.37-1.04 2.53-2.21 3.31v2.77h3.57c2.08-1.92 3.28-4.74 3.28-8.09z" />
      <path fill="#34A853" d="M12 23c2.97 0 5.46-.98 7.28-2.66l-3.57-2.77c-.98.66-2.23 1.06-3.71 1.06-2.86 0-5.29-1.93-6.16-4.53H2.18v2.84C3.99 20.53 7.7 23 12 23z" />
      <path fill="#FBBC05" d="M5.84 14.09c-.22-.66-.35-1.36-.35-2.09s.13-1.43.35-2.09V7.06H2.18C1.43 8.55 1 10.22 1 12s.43 3.45 1.18 4.94l2.85-2.22.81-.63z" />
      <path fill="#EA4335" d="M12 5.38c1.62 0 3.06.56 4.21 1.64l3.15-3.15C17.45 2.09 14.97 1 12 1 7.7 1 3.99 3.47 2.18 7.06l3.66 2.84c.87-2.6 3.3-4.52 6.16-4.52z" />
    </svg>
  ),
  Discord: (
    <svg className="h-[18px] w-[18px] shrink-0" viewBox="0 0 24 24" fill="#5865F2" aria-hidden="true">
      <path d="M20.317 4.37a19.791 19.791 0 0 0-4.885-1.515.074.074 0 0 0-.079.037c-.21.375-.444.864-.608 1.25a18.27 18.27 0 0 0-5.487 0 12.64 12.64 0 0 0-.617-1.25.077.077 0 0 0-.079-.037A19.736 19.736 0 0 0 3.677 4.37a.07.07 0 0 0-.032.027C.533 9.046-.32 13.58.099 18.057a.082.082 0 0 0 .031.057 19.9 19.9 0 0 0 5.993 3.03.078.078 0 0 0 .084-.028c.462-.63.874-1.295 1.226-1.994a.076.076 0 0 0-.041-.106 13.107 13.107 0 0 1-1.872-.892.077.077 0 0 1-.008-.128 10.2 10.2 0 0 0 .372-.292.074.074 0 0 1 .077-.01c3.928 1.793 8.18 1.793 12.062 0a.074.074 0 0 1 .078.01c.12.098.246.198.373.292a.077.077 0 0 1-.006.127 12.299 12.299 0 0 1-1.873.892.077.077 0 0 0-.041.107c.36.698.772 1.362 1.225 1.993a.076.076 0 0 0 .084.028 19.839 19.839 0 0 0 6.002-3.03.077.077 0 0 0 .032-.054c.5-5.177-.838-9.674-3.549-13.66a.061.061 0 0 0-.031-.03zM8.02 15.33c-1.183 0-2.157-1.085-2.157-2.419 0-1.333.956-2.419 2.157-2.419 1.21 0 2.176 1.096 2.157 2.42 0 1.333-.956 2.418-2.157 2.418zm7.975 0c-1.183 0-2.157-1.085-2.157-2.419 0-1.333.955-2.419 2.157-2.419 1.21 0 2.176 1.096 2.157 2.42 0 1.333-.946 2.418-2.157 2.418z" />
    </svg>
  ),
  GitHub: (
    <svg className="h-[18px] w-[18px] shrink-0" viewBox="0 0 24 24" fill="currentColor" aria-hidden="true">
      <path d="M12 2C6.477 2 2 6.484 2 12.017c0 4.425 2.865 8.18 6.839 9.504.5.092.682-.217.682-.483 0-.237-.008-.868-.013-1.703-2.782.605-3.369-1.343-3.369-1.343-.454-1.158-1.11-1.466-1.11-1.466-.908-.62.069-.608.069-.608 1.003.07 1.53 1.032 1.53 1.032.892 1.53 2.341 1.088 2.91.832.092-.647.35-1.088.636-1.338-2.22-.253-4.555-1.113-4.555-4.951 0-1.093.39-1.988 1.029-2.688-.103-.253-.446-1.272.098-2.65 0 0 .84-.27 2.75 1.026A9.564 9.564 0 0 1 12 6.844c.85.004 1.705.115 2.504.337 1.909-1.296 2.747-1.027 2.747-1.027.546 1.379.202 2.398.1 2.651.64.7 1.028 1.595 1.028 2.688 0 3.848-2.339 4.695-4.566 4.943.359.309.678.92.678 1.855 0 1.338-.012 2.419-.012 2.747 0 .268.18.58.688.482A10.019 10.019 0 0 0 22 12.017C22 6.484 17.522 2 12 2z" />
    </svg>
  ),
};

const TERMS = [
  ['บัญชีสมาชิก', 'บัญชีสมาชิกใช้สำหรับเข้าสู่ระบบและจัดการข้อมูลบัญชีของคุณ'],
  ['การรับประกันไอดีเกม', 'บัญชีเกมทุกรายการมีระยะเวลารับประกันเปลี่ยนรหัสผ่านและเข้าเล่นครั้งแรก 100% พร้อมการดูแลความปลอดภัย 30 วัน'],
  ['สิทธิ์การใช้ซอร์สโค้ด', 'ซอร์สโค้ดและ Assets ที่สั่งซื้อผ่านระบบสามารถนำไปพัฒนาต่อในเชิงพาณิชย์ได้ตามเงื่อนไขลิขสิทธิ์'],
];

const focusRing =
  'focus-visible:outline-2 focus-visible:outline-offset-2 focus-visible:outline-current';

const inputCls =
  'h-11 w-full border border-line bg-bg-sunken px-3.5 text-[15px] text-ink outline-none transition-[border-color,box-shadow] duration-150 placeholder:text-faint hover:border-line-strong focus:border-line-strong focus:shadow-[0_0_0_3px_color-mix(in_srgb,currentColor_16%,transparent)] aria-[invalid=true]:border-red-500 motion-reduce:transition-none';

/** Collapsible block: height + opacity transition that answers the user's action. */
function Reveal({ open, children }: { open: boolean; children: React.ReactNode }) {
  return (
    <div
      inert={!open}
      className={`grid transition-[grid-template-rows,opacity] duration-300 ease-out motion-reduce:transition-none ${
        open ? 'grid-rows-[1fr] opacity-100' : 'grid-rows-[0fr] opacity-0'
      }`}
    >
      <div className="-mx-1 -mt-1 min-h-0 overflow-hidden px-1 pt-1">{children}</div>
    </div>
  );
}

function Field({ id, label, action, children }: { id: string; label: string; action?: React.ReactNode; children: React.ReactNode }) {
  return (
    <div className="pb-4">
      <div className="mb-1.5 flex items-center justify-between gap-3">
        <label htmlFor={id} className="text-sm font-medium text-ink">
          {label}
        </label>
        {action}
      </div>
      {children}
    </div>
  );
}

export default function AuthApp() {
  const [isSignUp, setIsSignUp] = useState(false);
  const [hasEnteredEmail, setHasEnteredEmail] = useState(false);
  const [showPassword, setShowPassword] = useState(false);
  const [loading, setLoading] = useState(false);
  const [pending] = useState<Provider | null>(null);
  const [showTerms, setShowTerms] = useState(false);
  const [theme, setTheme] = useState<'dark' | 'light'>('dark');

  const [email, setEmail] = useState('');
  const [username, setUsername] = useState('');
  const [password, setPassword] = useState('');
  const [confirmPassword, setConfirmPassword] = useState('');

  const [alert, setAlert] = useState<Notice | null>(null);
  const [invalid, setInvalid] = useState<FieldId | null>(null);

  const termsTrigger = useRef<HTMLButtonElement>(null);
  const termsClose = useRef<HTMLButtonElement>(null);

  useEffect(() => {
    const savedTheme = (localStorage.getItem('koddykub-theme') as 'dark' | 'light') || 'dark';
    setTheme(savedTheme);
    document.documentElement.dataset.theme = savedTheme;

    const mode = new URLSearchParams(window.location.search).get('mode');
    if (mode === 'signup' || mode === 'register') setIsSignUp(true);
  }, []);

  // Step 2 of sign-in: move focus to the password field once it opens.
  useEffect(() => {
    if (hasEnteredEmail) document.getElementById('password')?.focus();
  }, [hasEnteredEmail]);

  // Terms dialog: Esc closes, page scroll locked, focus moves in and returns.
  useEffect(() => {
    if (!showTerms) return;
    const onKey = (e: KeyboardEvent) => e.key === 'Escape' && setShowTerms(false);
    const prevOverflow = document.body.style.overflow;
    const trigger = termsTrigger.current;
    document.body.style.overflow = 'hidden';
    document.addEventListener('keydown', onKey);
    termsClose.current?.focus();
    return () => {
      document.body.style.overflow = prevOverflow;
      document.removeEventListener('keydown', onKey);
      trigger?.focus();
    };
  }, [showTerms]);

  const toggleTheme = () => {
    const next = theme === 'dark' ? 'light' : 'dark';
    setTheme(next);
    document.documentElement.dataset.theme = next;
    localStorage.setItem('koddykub-theme', next);
  };

  const fail = (field: FieldId, message: string) => {
    setAlert({ message, type: 'error' });
    setInvalid(field);
    document.getElementById(field)?.focus();
  };

  const bind = (id: FieldId, value: string, set: (v: string) => void) => ({
    id,
    value,
    onChange: (e: React.ChangeEvent<HTMLInputElement>) => {
      set(e.target.value);
      if (invalid === id) setInvalid(null);
    },
    'aria-invalid': invalid === id,
    'aria-describedby': invalid === id ? 'form-alert' : undefined,
  });

  const handleLoginSuccess = (user: User) => {
    localStorage.setItem('koddykub_user', JSON.stringify(user));
    setAlert({ message: `ยินดีต้อนรับคุณ ${user.name} กำลังเข้าสู่ระบบ...`, type: 'success' });
    setLoading(true);
    setTimeout(() => {
      window.location.href = new URLSearchParams(window.location.search).get('returnUrl') || '/';
    }, 700);
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (loading) return;
    setAlert(null);
    setInvalid(null);

    const cleanEmail = email.trim();
    if (!cleanEmail || !cleanEmail.includes('@') || !cleanEmail.includes('.')) {
      return fail('email', 'กรุณากรอกอีเมลให้ถูกต้อง เช่น name@example.com');
    }

    if (!isSignUp && !hasEnteredEmail) {
      setHasEnteredEmail(true);
      return;
    }

    if (isSignUp) {
      const cleanUser = username.trim();
      if (cleanUser.length < 3) return fail('username', 'ชื่อผู้ใช้ต้องมีอย่างน้อย 3 ตัวอักษร');
      if (password.length < 6) return fail('password', 'รหัสผ่านต้องมีอย่างน้อย 6 ตัวอักษร');
      if (password !== confirmPassword) return fail('confirmPassword', 'รหัสผ่านทั้งสองช่องไม่ตรงกัน');

      handleLoginSuccess({
        id: `user_${Date.now()}`,
        name: cleanUser,
        email: cleanEmail,
        role: 'สมาชิก',
        points: 0,
        provider: 'email',
        avatarText: cleanUser.slice(0, 2).toUpperCase(),
        orders: [],
      });
      return;
    }

    if (!password) return fail('password', 'กรุณากรอกรหัสผ่าน');

    let user: User | null = null;
    try {
      const stored = localStorage.getItem('koddykub_user');
      if (stored) {
        user = JSON.parse(stored);
        if (user) user.email = cleanEmail;
      }
    } catch {
      user = null;
    }
    if (!user) {
      const autoName = cleanEmail.split('@')[0];
      user = {
        id: `user_${Date.now()}`,
        name: autoName,
        email: cleanEmail,
        role: 'สมาชิก',
        points: 0,
        provider: 'email',
        avatarText: autoName.slice(0, 2).toUpperCase(),
        orders: [],
      };
    }
    handleLoginSuccess(user);
  };

  const toggleMode = () => {
    setAlert(null);
    setInvalid(null);
    setIsSignUp(!isSignUp);
    setHasEnteredEmail(false);
  };

  const requestReset = () => {
    if (!email.trim()) return fail('email', 'กรอกอีเมลก่อน แล้วกด "ลืมรหัสผ่าน" อีกครั้ง');
    setAlert({ message: 'ระบบรีเซ็ตรหัสผ่านยังไม่เปิดให้ใช้งาน กรุณาติดต่อร้านเพื่อขอความช่วยเหลือ', type: 'error' });
  };

  const showPasswordField = isSignUp || hasEnteredEmail;
  const busy = loading || pending !== null;

  return (
    <div className="flex min-h-screen flex-col overflow-x-hidden bg-bg text-ink selection:bg-invert-bg selection:text-invert-fg">
      <nav className="sticky top-0 z-50 w-full border-b border-line bg-bg/95 backdrop-blur-sm" id="site-nav">
        <div className="flex h-12 items-stretch justify-between">
          <div className="flex min-w-0 items-stretch">
            <a
              className={`flex items-center border-r border-line px-4 transition-opacity hover:opacity-70 sm:px-5 ${focusRing}`}
              href="/"
              title="หน้าแรก KODDYKUB"
            >
              <img alt="KODDYKUB" className="themed-logo h-5 w-auto sm:h-6" src="/assets/koddykub-logo.png" />
            </a>
            <div className="hidden items-center border-r border-line px-4 text-sm text-muted sm:flex">ระบบสมาชิก</div>
          </div>

          <div className="flex shrink-0 items-stretch">
            <a
              className={`group flex h-full items-center gap-2 border-l border-line px-4 text-sm text-muted transition-colors hover:text-ink ${focusRing}`}
              href="/"
            >
              <ArrowLeft className="h-4 w-4 transition-transform group-hover:-translate-x-0.5 motion-reduce:transition-none" aria-hidden="true" />
              กลับหน้าร้าน
            </a>
            <button
              aria-label={theme === 'dark' ? 'สลับเป็นโหมดสว่าง' : 'สลับเป็นโหมดมืด'}
              className={`flex w-12 cursor-pointer items-center justify-center border-l border-line text-muted transition-colors hover:bg-invert-bg hover:text-invert-fg ${focusRing}`}
              type="button"
              onClick={toggleTheme}
            >
              {theme === 'dark' ? <Sun className="h-4 w-4" /> : <Moon className="h-4 w-4" />}
            </button>
          </div>
        </div>
      </nav>

      <main className="flex flex-1 items-center justify-center px-4 py-8 sm:px-6 sm:py-12">
        <div className="relative w-full max-w-[480px] border border-line bg-bg px-6 py-9 sm:px-10 sm:py-11">
          <span aria-hidden="true" className="tick tick-half z-[31] -top-[5px] -left-[6px]"></span>
          <span aria-hidden="true" className="tick tick-half z-[31] -top-[5px] -right-[5px]"></span>
          <span aria-hidden="true" className="tick tick-half z-[31] -bottom-[5px] -left-[6px]"></span>
          <span aria-hidden="true" className="tick tick-half z-[31] -bottom-[5px] -right-[5px]"></span>

          <header className="text-center">
            <h1 className="font-display text-[22px] font-semibold leading-tight text-ink-strong min-[420px]:text-[26px]">
              {isSignUp ? 'Join KODDYKUB' : 'Welcome to KODDYKUB'}
            </h1>
            <p className="mx-auto mt-3 max-w-xs text-sm leading-relaxed text-muted">
              {isSignUp
                ? 'สมัครสมาชิกฟรีเพื่อเข้าสู่ระบบ'
                : 'เข้าสู่ระบบเพื่อดูข้อมูลบัญชีของคุณ'}
            </p>
          </header>

          <div className="mt-8 grid grid-cols-3 gap-2.5">
            {(['Google', 'Discord', 'GitHub'] as Provider[]).map((p) => (
              <button
                key={p}
                type="button"
                disabled
                aria-disabled="true"
                title={`${p} ยังไม่เปิดให้ใช้งาน`}
                className={`flex h-11 cursor-pointer items-center justify-center gap-2 border border-line bg-bg text-[13px] font-medium text-ink transition-colors hover:border-line-strong hover:bg-bg-sunken disabled:cursor-not-allowed disabled:opacity-50 motion-reduce:transition-none ${focusRing}`}
              >
                {pending === p ? <Loader2 className="h-[18px] w-[18px] animate-spin motion-reduce:animate-none" aria-hidden="true" /> : ICONS[p]}
                <span>{p}</span>
              </button>
            ))}
          </div>

          <p className="mt-3 text-center text-xs text-muted">การเข้าสู่ระบบด้วยบัญชีโซเชียลยังไม่เปิดให้ใช้งาน</p>

          <div className="my-6 flex items-center gap-4 text-xs text-muted">
            <span aria-hidden="true" className="h-px flex-1 bg-line"></span>
            หรือใช้อีเมล
            <span aria-hidden="true" className="h-px flex-1 bg-line"></span>
          </div>

          {alert && (
            <div
              id="form-alert"
              role={alert.type === 'error' ? 'alert' : 'status'}
              className={`mb-4 flex items-start gap-2.5 border border-line border-l-2 bg-bg-sunken px-3 py-2.5 text-sm text-ink transition duration-200 starting:-translate-y-1 starting:opacity-0 motion-reduce:transition-none ${
                alert.type === 'error' ? 'border-l-red-500' : 'border-l-emerald-500'
              }`}
            >
              {alert.type === 'error' ? (
                <AlertCircle className="mt-0.5 h-4 w-4 shrink-0 text-red-500" aria-hidden="true" />
              ) : (
                <CheckCircle2 className="mt-0.5 h-4 w-4 shrink-0 text-emerald-500" aria-hidden="true" />
              )}
              <span className="leading-snug">{alert.message}</span>
            </div>
          )}

          <form onSubmit={handleSubmit} noValidate>
            <Reveal open={isSignUp}>
              <Field id="username" label="ชื่อผู้ใช้">
                <input
                  {...bind('username', username, setUsername)}
                  type="text"
                  placeholder="เช่น gamer_pro"
                  className={inputCls}
                  autoComplete="username"
                />
              </Field>
            </Reveal>

            <Field id="email" label="อีเมล">
              <input
                {...bind('email', email, setEmail)}
                type="email"
                inputMode="email"
                placeholder="name@example.com"
                className={inputCls}
                autoComplete="email"
                autoFocus
              />
            </Field>

            <Reveal open={showPasswordField}>
              <Field
                id="password"
                label="รหัสผ่าน"
                action={
                  !isSignUp && (
                    <button
                      type="button"
                      onClick={requestReset}
                      className={`cursor-pointer text-xs text-muted underline-offset-4 transition-colors hover:text-ink hover:underline ${focusRing}`}
                    >
                      ลืมรหัสผ่าน
                    </button>
                  )
                }
              >
                <div className="relative">
                  <input
                    {...bind('password', password, setPassword)}
                    type={showPassword ? 'text' : 'password'}
                    placeholder={isSignUp ? 'อย่างน้อย 6 ตัวอักษร' : 'รหัสผ่านของคุณ'}
                    className={`${inputCls} pr-11`}
                    autoComplete={isSignUp ? 'new-password' : 'current-password'}
                  />
                  <button
                    type="button"
                    onClick={() => setShowPassword(!showPassword)}
                    aria-label={showPassword ? 'ซ่อนรหัสผ่าน' : 'แสดงรหัสผ่าน'}
                    aria-pressed={showPassword}
                    className={`absolute inset-y-0 right-0 flex w-11 cursor-pointer items-center justify-center text-muted transition-colors hover:text-ink ${focusRing}`}
                  >
                    {showPassword ? <EyeOff className="h-4 w-4" /> : <Eye className="h-4 w-4" />}
                  </button>
                </div>
              </Field>
            </Reveal>

            <Reveal open={isSignUp}>
              <Field id="confirmPassword" label="ยืนยันรหัสผ่าน">
                <input
                  {...bind('confirmPassword', confirmPassword, setConfirmPassword)}
                  type={showPassword ? 'text' : 'password'}
                  placeholder="พิมพ์รหัสผ่านอีกครั้ง"
                  className={inputCls}
                  autoComplete="new-password"
                />
              </Field>
            </Reveal>

            <button
              type="submit"
              disabled={busy}
              aria-busy={loading}
              className={`mt-1 inline-flex h-11 w-full cursor-pointer items-center justify-center gap-2 rounded-none bg-invert-bg px-5 text-sm font-semibold text-invert-fg transition-opacity hover:opacity-90 active:opacity-80 disabled:cursor-not-allowed disabled:opacity-60 motion-reduce:transition-none ${focusRing}`}
            >
              {loading && <Loader2 className="h-4 w-4 animate-spin motion-reduce:animate-none" aria-hidden="true" />}
              {loading
                ? 'กำลังเข้าสู่ระบบ...'
                : isSignUp
                ? 'สร้างบัญชี'
                : hasEnteredEmail
                ? 'เข้าสู่ระบบ'
                : 'ดำเนินการต่อด้วยอีเมล'}
            </button>
          </form>

          <p className="mt-6 text-center text-sm text-muted">
            {isSignUp ? 'มีบัญชีอยู่แล้ว?' : 'ยังไม่มีบัญชี?'}
            <button
              type="button"
              onClick={toggleMode}
              className={`ml-1.5 cursor-pointer font-medium text-ink-strong underline underline-offset-4 transition-opacity hover:opacity-70 ${focusRing}`}
            >
              {isSignUp ? 'เข้าสู่ระบบ' : 'สมัครสมาชิก'}
            </button>
          </p>
        </div>
      </main>

      <footer className="border-t border-line bg-bg">
        <div className="mx-auto flex max-w-[1280px] flex-col items-center justify-between gap-2 px-4 py-4 text-center text-xs text-muted sm:flex-row sm:px-6 sm:text-left">
          <p>© 2026 KODDYKUB ร้านขายไอดีเกมและซอร์สโค้ดเกม</p>
          <button
            ref={termsTrigger}
            type="button"
            onClick={() => setShowTerms(true)}
            className={`cursor-pointer text-muted underline-offset-4 transition-colors hover:text-ink hover:underline ${focusRing}`}
          >
            ข้อกำหนดการให้บริการและนโยบายความเป็นส่วนตัว
          </button>
        </div>
      </footer>

      {showTerms && (
        <div
          className="fixed inset-0 z-[60] flex items-center justify-center bg-black/70 p-4 backdrop-blur-sm transition-opacity duration-200 starting:opacity-0 motion-reduce:transition-none"
          onClick={(e) => e.target === e.currentTarget && setShowTerms(false)}
        >
          <div
            role="dialog"
            aria-modal="true"
            aria-labelledby="terms-title"
            className="max-h-[85vh] w-full max-w-[520px] overflow-y-auto border border-line-strong bg-bg p-6 text-ink shadow-2xl transition duration-200 starting:translate-y-2 starting:opacity-0 motion-reduce:transition-none"
          >
            <div className="mb-4 flex items-start justify-between gap-4 border-b border-line pb-4">
              <h2 id="terms-title" className="font-display text-lg font-medium text-ink-strong">
                ข้อกำหนดสำหรับสมาชิก KODDYKUB
              </h2>
              <button
                ref={termsClose}
                type="button"
                onClick={() => setShowTerms(false)}
                aria-label="ปิดหน้าต่าง"
                className={`-m-1 cursor-pointer p-1 text-muted transition-colors hover:text-ink ${focusRing}`}
              >
                <X className="h-5 w-5" />
              </button>
            </div>
            <ol className="flex list-decimal flex-col gap-3 pl-5 text-sm leading-relaxed text-muted marker:text-faint">
              {TERMS.map(([title, body]) => (
                <li key={title}>
                  <strong className="font-medium text-ink">{title}:</strong> {body}
                </li>
              ))}
            </ol>
          </div>
        </div>
      )}
    </div>
  );
}