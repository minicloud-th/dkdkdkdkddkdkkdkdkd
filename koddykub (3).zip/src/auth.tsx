/**
 * Sign-in / sign-up page entry. Mounts the form in AuthApp.
 * The landing page's navbar and member dialog live in public/auth.js.
 */
import { createRoot } from 'react-dom/client';
import AuthApp from './AuthApp';

const container = document.getElementById('root');
if (container) createRoot(container).render(<AuthApp />);